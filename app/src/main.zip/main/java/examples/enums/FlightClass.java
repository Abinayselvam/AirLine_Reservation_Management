package examples.enums;


public enum  FlightClass {
    ECONOMY,

    PREMIUM_ECONOMY,

    BUSINESS,

    FIRST_CLASS
}
