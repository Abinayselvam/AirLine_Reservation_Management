package examples.operations;

import examples.service.FlightService;
import examples.service.iservice.IFlightService;

import java.util.Scanner;

public class FlightMenu {

    public static void start() {

        Scanner sc = new Scanner(System.in);

        IFlightService service = new FlightService();

        while (true) {

            System.out.println("\n===== FLIGHT SEARCH =====");
            System.out.println("1. Search Flights");
            System.out.println("2. View Grouped by Airline");
            System.out.println("3. View Average Fare by Airline");
            System.out.println("4. View Cheapest Flight per Route");
            System.out.println("5. View Grouped by Price Range");
            System.out.println("6. View Grouped by Departure Time Slot");
            System.out.println("7. Back");

            System.out.print("Choice : ");

            int choice = Integer.parseInt(sc.nextLine());

            switch (choice) {

                case 1 -> service.searchFlights();

                case 2 -> service.viewGroupedByAirline();

                case 3 -> service.viewAverageFareByAirline();

                case 4 -> service.viewCheapestFlightsByRoute();

                case 5 -> service.viewGroupedByPriceRange();

                case 6 -> service.viewGroupedByDepartureSlot();
                case 7 -> {

                    System.out.print("Flight ID : ");

                    int flightId = Integer.parseInt(sc.nextLine());

                    new examples.service.SeatService().displaySeatMap(flightId);
                }

                case 8 -> {

                    System.out.print("Flight ID : ");

                    int flightId = Integer.parseInt(sc.nextLine());

                    System.out.print("Number of Passengers : ");

                    int count = Integer.parseInt(sc.nextLine());

                    new examples.service.SeatService().selectSeats(flightId, count);
                }
                case 9 -> AirportMenu.start();



                case 10 -> {
                    service.viewPriceCalendar();
                    System.out.println("10. Price Calendar (±3 days)");
                }

                case 11 ->{
                    service.flexibleDateSearch();
                System.out.println("11. Flexible Date Search (±3 days)");
                }
                case 12 -> {
                    service.airportAutocomplete();
                System.out.println("12. Airport Autocomplete");
                }

                case 13 -> { return; }


                default -> System.out.println("Invalid Choice");
            }
        }
    }
}