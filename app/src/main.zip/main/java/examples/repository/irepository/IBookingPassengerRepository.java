package examples.repository.irepository;

import examples.model.BookingPassenger;

import java.util.List;

public interface IBookingPassengerRepository {

    boolean saveAll(List<BookingPassenger> passengers);

    List<BookingPassenger> findByBookingId(int bookingId);

    void updateDetails(BookingPassenger passenger);

    void updateSeatNumber(int passengerBookingId, String newSeatNumber);

    boolean updateCancelled(int passengerBookingId, boolean cancelled);

    List<BookingPassenger> findAll();
}